<template>
  <v-layout>
    <v-flex>
      <v-flex class="text-center">
        <blockquote class="blockquote">
          <div class="text-h2">
            Making sense of <v-icon size="50px">
              mdi-code-json
            </v-icon> like <v-icon size="50px">
              mdi-auto-fix
            </v-icon>
          </div>
        </blockquote>

        <h2>
          An open source tool to explore complex JSON.
        </h2>
        <p>
          Easily interact with Open APIs such as the Cisco Meraki Dashboard API, or just paste in JSON data to begin the magic.
        </p>
      </v-flex>

      <v-flex>
        <v-container>
          <v-card>
            <v-card-title>
              Resources
            </v-card-title>
            <v-card-text>
              <v-list>
                <v-list-item><a href="https://github.com/dexterlabora/json-magic" target="_blank">GitHub</a></v-list-item>
                <v-list-item><a href="https://meraki.io" target="_blank">Cisco Meraki Developers</a></v-list-item>
              </v-list>
            </v-card-text>
          </v-card>
        </v-container>
      </v-flex>
    </v-flex>
  </v-layout>
</template>
