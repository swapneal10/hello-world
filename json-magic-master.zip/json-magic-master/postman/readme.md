# Postman Visualization Scripts

Postman supports the ability to "Visualize" your response data. By using these scripts, we can take advantage of that and render a JSON Magic view and transform the JSON.

# Installaion
- Copy the contents of `postman-viz-embed.js` into your Postman Request's **Tests** script area
- Run your endpoint
- Select **Visualize**

# tl;dr

The embed script assigns the Postman visualization template to the `postman-viz-jsonmgagic-template.html` file, and then renders the web visualization